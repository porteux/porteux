# xdg-desktop-portal-gnome

A backend implementation for [xdg-desktop-portal](http://github.com/flatpak/xdg-desktop-portal)
that is using GTK and various pieces of GNOME infrastructure, such as the
org.gnome.Shell.Screenshot or org.gnome.SessionManager D-Bus interfaces.

## Building xdg-desktop-portal-gnome

xdg-desktop-portal-gnome depends on xdg-desktop-portal and xdg-desktop-portal-gtk.
