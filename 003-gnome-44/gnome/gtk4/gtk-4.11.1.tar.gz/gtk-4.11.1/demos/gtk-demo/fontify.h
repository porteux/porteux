#pragma once

#include <gtk/gtk.h>

void fontify (const char    *format,
              GtkTextBuffer *buffer);
