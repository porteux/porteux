#! /bin/sh

. /etc/os-release

echo $PRETTY_NAME
