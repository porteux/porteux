.. _gtk4-demo-application(1):

=====================
gtk4-demo-application
=====================

--------------------------
Demonstrate GtkApplication
--------------------------


SYNOPSIS
--------
|   **gtk4-demo-application**


DESCRIPTION
-----------

``gtk4-demo-application`` is an example application used by ``gtk4-demo``.

There is no need to call it manually.
