.. _gtk4-node-editor(1):

=================
gtk4-node-editor
=================

-----------------
Editor render nodes
-----------------

SYNOPSIS
--------

|   **gtk4-node-editor** [OPTIONS...]

DESCRIPTION
-----------

``gtk4-node-editor`` is a utility to show and edit render node files.
Such render node files can be obtained e.g. from the GTK inspector.

OPTIONS
-------

``-h, --help``

  Show the application help.
