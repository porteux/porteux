Title: Using GTK on Apple macOS
Slug: gtk-osx

The Apple macOS port of GTK is an implementation of GDK (and therefore GTK)
on top of the Quartz API.

Currently, the macOS port does not use any additional commandline options
or environment variables.

For up-to-date information about the current status of this port, see the
[project page](https://wiki.gnome.org/Projects/GTK/OSX).
