Title: Migrating from GTK 2.x to GTK 4
Slug: gtk-migrating-2-to-4

If your application is still using GTK 2, you should first convert it to GTK 3,
by following the [migration guide](https://developer.gnome.org/gtk3/stable/gtk-migrating-2-to-3.html)
in the GTK 3 documentation, and then follow [these instructions](#gtk-migrating-3-to-4).
