#include <libei.h>
#include <libeis.h>

/* This is a build-test only */

using namespace std;

int
main(void)
{
	return 0;
}
