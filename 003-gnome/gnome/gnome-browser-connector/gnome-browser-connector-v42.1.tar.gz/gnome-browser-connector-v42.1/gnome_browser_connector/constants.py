# SPDX-License-Identifer: GPL-3.0-or-later

CONNECTOR_ARG = 'connector'
